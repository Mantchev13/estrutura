"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var readline = require("readline");
// Função para calcular montante composto
function calcularMontante(capital, taxaMensal, meses) {
    return capital * Math.pow(1 + taxaMensal, meses);
}
// Função para formatar valor em Real brasileiro
function formatarMoeda(valor) {
    return valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}
// Leitora para entrada no console
var rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
});
console.log('Calculadora de Juros Compostos');
console.log('Taxa fixa de 0,5% ao mês.');
rl.question('Digite o valor do capital inicial (ex: 1000): ', function (input) {
    var capital = parseFloat(input.replace(',', '.'));
    if (isNaN(capital) || capital <= 0) {
        console.log('Por favor, insira um valor válido maior que zero para o capital.');
        rl.close();
        return;
    }
    var taxaMensal = 0.005; // 0,5% ao mês em decimal
    var montante12 = calcularMontante(capital, taxaMensal, 12);
    var montante24 = calcularMontante(capital, taxaMensal, 24);
    console.log("\nResultados para capital de ".concat(formatarMoeda(capital), ":"));
    console.log("Ap\u00F3s 12 meses, montante: ".concat(formatarMoeda(montante12)));
    console.log("Ap\u00F3s 24 meses, montante: ".concat(formatarMoeda(montante24)));
    rl.close();
});
