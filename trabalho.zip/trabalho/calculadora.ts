import * as readline from 'readline';

// Função para calcular montante composto
function calcularMontante(capital: number, taxaMensal: number, meses: number): number {
  return capital * Math.pow(1 + taxaMensal, meses);
}

// Função para formatar valor em Real brasileiro
function formatarMoeda(valor: number): string {
  return valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

// Leitora para entrada no console
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

console.log('Calculadora de Juros Compostos');
console.log('Taxa fixa de 0,5% ao mês.');

rl.question('Digite o valor do capital inicial (ex: 1000): ', (input) => {
  const capital = parseFloat(input.replace(',', '.'));

  if (isNaN(capital) || capital <= 0) {
    console.log('Por favor, insira um valor válido maior que zero para o capital.');
    rl.close();
    return;
  }

  const taxaMensal = 0.005; // 0,5% ao mês em decimal

  const montante12 = calcularMontante(capital, taxaMensal, 12);
  const montante24 = calcularMontante(capital, taxaMensal, 24);

  console.log(`\nResultados para capital de ${formatarMoeda(capital)}:`)
  console.log(`Após 12 meses, montante: ${formatarMoeda(montante12)}`);
  console.log(`Após 24 meses, montante: ${formatarMoeda(montante24)}`);

  rl.close();
});



