import * as fs from 'fs';
import * as readline from 'readline';

// Função para ler o conteúdo do arquivo
function lerArquivo(caminho: string): Promise<string> {
  return new Promise((resolve, reject) => {
    fs.readFile(caminho, 'utf-8', (err, data) => {
      if (err) reject(err);
      else resolve(data);
    });
  });
}

// Função principal
async function main() {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  // Prompts utilitários
  const question = (query: string): Promise<string> =>
    new Promise(resolve => rl.question(query, resolve));

  try {
    const caminho = await question('Informe o caminho do arquivo de texto: ');
    const delimitador = await question('Informe o delimitador a ser usado (ex: "," ou " "): ');
    const conteudo = await lerArquivo(caminho);

    // Transforma o texto em palavras e junta com o delimitador escolhido
    const palavras = conteudo
      .split(/\s+/)
      .filter(p => p.trim().length > 0);
    const textoDelimitado = palavras.join(delimitador);

    const busca = await question('Digite a palavra que deseja buscar: ');
    const palavrasSeparadas = textoDelimitado.split(delimitador);

    let ocorrencias = 0;
    const posicoes: number[] = [];
    let deslocamentos = 0;

    for (let i = 0; i < palavrasSeparadas.length; i++) {
      deslocamentos++;
      if (palavrasSeparadas[i] === busca) {
        ocorrencias++;
        posicoes.push(i);
      }
    }

    console.log('\n=== Resultado ===');
    console.log(`Total de ocorrências de "${busca}": ${ocorrencias}`);
    console.log(`Posições encontradas: ${posicoes.join(', ') || 'Nenhuma'}`);
    console.log(`Total de deslocamentos feitos: ${deslocamentos}`);
  } catch (erro) {
    console.error('Erro ao executar o programa:', erro);
  } finally {
    rl.close();
  }
}

main();
