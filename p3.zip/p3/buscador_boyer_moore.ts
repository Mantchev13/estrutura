import * as fs from 'fs';
import * as readline from 'readline';

// Função para ler o arquivo
function lerArquivo(caminho: string): Promise<string> {
  return new Promise((resolve, reject) => {
    fs.readFile(caminho, 'utf-8', (err, data) => {
      if (err) reject(err);
      else resolve(data);
    });
  });
}

// Construir a tabela de deslocamento (Bad Character Heuristic)
function buildBadCharTable(pattern: string): Map<string, number> {
  const table = new Map<string, number>();
  const m = pattern.length;

  for (let i = 0; i < m - 1; i++) {
    table.set(pattern[i], m - 1 - i);
  }

  return table;
}

// Algoritmo de Boyer-Moore (Bad Character Heuristic simplificado)
function boyerMooreSearch(text: string, pattern: string): { posicoes: number[], deslocamentos: number } {
  const n = text.length;
  const m = pattern.length;
  const badCharTable = buildBadCharTable(pattern);
  const posicoes: number[] = [];
  let deslocamentos = 0;

  let i = 0;
  while (i <= n - m) {
    let j = m - 1;

    while (j >= 0 && pattern[j] === text[i + j]) {
      j--;
      deslocamentos++;
    }

    if (j < 0) {
      posicoes.push(i);
      deslocamentos++; // Para a comparação final bem-sucedida
      i += m;
    } else {
      deslocamentos++;
      const char = text[i + j];
      const shift = badCharTable.get(char) ?? m;
      i += Math.max(1, shift - (m - 1 - j));
    }
  }

  return { posicoes, deslocamentos };
}

// Função principal
async function main() {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  const question = (query: string): Promise<string> =>
    new Promise(resolve => rl.question(query, resolve));

  try {
    const caminho = await question('Informe o caminho do arquivo de texto: ');
    const delimitador = await question('Informe o delimitador a ser usado (ex: "," ou " "): ');
    const conteudo = await lerArquivo(caminho);

    const palavras = conteudo
      .split(/\s+/)
      .filter(p => p.trim().length > 0);
    const textoDelimitado = palavras.join(delimitador);

    const busca = await question('Digite a palavra que deseja buscar: ');

    const { posicoes, deslocamentos } = boyerMooreSearch(textoDelimitado, busca);

    console.log('\n=== Resultado ===');
    console.log(`Total de ocorrências de "${busca}": ${posicoes.length}`);
    console.log(`Deslocamentos realizados: ${deslocamentos}`);
    console.log(`Índices onde a palavra foi encontrada: ${posicoes.join(', ') || 'Nenhuma'}`);
  } catch (erro) {
    console.error('Erro ao executar o programa:', erro);
  } finally {
    rl.close();
  }
}

main();
